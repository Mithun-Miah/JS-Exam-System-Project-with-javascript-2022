let bangla = document.getElementById("bangla");
let english = document.getElementById("english");
let physics = document.getElementById("physics");
let math = document.getElementById("math");
let add_btn = document.getElementById("add_btn");
let inputs = document.querySelectorAll(".inputs");
let clear_btn = document.getElementById("clear_btn");

add_btn.addEventListener('click', function(){
    //pera.preventDefault();
    if(bangla.value == "" || english.value == "" || physics.value == "" || math.value == ""){
        alert("Please Fillup All Field");
    }else if(bangla.value < 0 || english.value < 0 || physics.value < 0 || math.value < 0){
        alert("Input Positive Number");
    }else if(bangla.value > 100 || english.value > 100 || physics.value > 100 || math.value > 100){
        alert("Number Exist");
    }else{
        let newBangla = parseInt(bangla.value);
        let newEnglish = parseInt(english.value);
        let newPhysics = parseInt(physics.value);
        let newMath = parseInt(math.value);

        let newTotal_mark = document.getElementById("total_mark");

        let Total_mark = newBangla+newEnglish+newPhysics+newMath;
        newTotal_mark.innerHTML = Total_mark;
        newTotal_mark.style.color = "#ec67dd";
        newTotal_mark.style.background = "#90e999";

        let avg_mark = document.getElementById("avg_mark");
        let avg = Total_mark/4;
        avg_mark.innerHTML = avg;

        let grade = document.getElementById("grade");
        let result = document.getElementById("result");
        let golden = document.getElementById("golden");

        if(avg > 80 && avg < 100){
            grade.innerHTML = "A+";
            result.innerHTML = "You Are Passed";
            golden.innerHTML = "Congratulations You Got Golden A+";
            golden.style.color = "rgb(229, 252, 9)";
            golden.style.textShadow = "2px 3px 5px black";
        }else if(avg > 70 && avg < 80){
            grade.innerHTML = "A";
            result.innerHTML = "You Are Passed";
            golden.innerHTML = "";
        }else if(avg > 60 && avg < 70){
            grade.innerHTML = "A-";
            result.innerHTML = "You Are Passed";
            golden.innerHTML = "";
        }else if(avg > 50 && avg < 60){
            grade.innerHTML = "B";
            result.innerHTML = "You Are Passed";
            golden.innerHTML = "";
        }else if(avg > 40 && avg < 50){
            grade.innerHTML = "C";
            result.innerHTML = "You Are Passed";
            golden.innerHTML = "";
        }else if(avg > 33 && avg < 40){
            grade.innerHTML = "D";
            result.innerHTML = "You Are Passed";
            golden.innerHTML = "";
        }else{
            grade.innerHTML = "F";
            result.innerHTML = "You Are Failed";
            golden.innerHTML = "";
        }
    }
});

/*clear_btn.addEventListener('click', function(){
	document.querySelectorAll(".inputs").value = '';
});*/